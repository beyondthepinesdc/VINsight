
# VINsight Monorepo

This is the MVP prototype for VINsight. It includes:

- `frontend/` - Next.js frontend for VIN + PDF uploads
- `backend/` - FastAPI backend with PDF parsing and VIN decoding

## Local Dev Instructions

### Backend (FastAPI)
```bash
cd backend
pip install fastapi uvicorn PyMuPDF requests
uvicorn main:app --reload --port 8000
```

### Frontend (Next.js)
```bash
cd frontend
npm install
npm run dev
```

Then open http://localhost:3000

## Deployment
- Deploy frontend to **Vercel**
- Deploy backend to **Render** or **Railway**
