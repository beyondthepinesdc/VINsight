from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import fitz  # PyMuPDF
import requests

app = FastAPI()

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class VINRequest(BaseModel):
    vin: str

@app.post("/decode-vin")
def decode_vin(data: VINRequest):
    vin = data.vin
    url = f"https://vpic.nhtsa.dot.gov/api/vehicles/decodevinvalues/{vin}?format=json"
    r = requests.get(url)
    return r.json()

@app.post("/analyze-pdf")
async def analyze_pdf(file: UploadFile = File(...)):
    text_output = ""
    with fitz.open(stream=await file.read(), filetype="pdf") as doc:
        for page in doc:
            text_output += page.get_text()

    # Simple keyword check
    flags = []
    keywords = ["commercial", "fleet", "rental", "uber", "lyft", "tnc", "delivery"]
    for word in keywords:
        if word in text_output.lower():
            flags.append(word)

    return {
        "flags_detected": flags,
        "summary": f"{len(flags)} potential rideshare-related keywords found."
    }