import { useState } from 'react';
import axios from 'axios';

export default function Home() {
  const [vin, setVin] = useState('');
  const [file, setFile] = useState(null);
  const [result, setResult] = useState(null);

  const handleSubmit = async () => {
    let response = {};

    if (vin) {
      const vinRes = await axios.post('http://localhost:8000/decode-vin', { vin });
      response.vinData = vinRes.data;
    }

    if (file) {
      const formData = new FormData();
      formData.append('file', file);
      const pdfRes = await axios.post('http://localhost:8000/analyze-pdf', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      response.pdfData = pdfRes.data;
    }

    setResult(response);
  };

  return (
    <div style={{ padding: 40 }}>
      <h1>VINsight Prototype</h1>
      <input
        type="text"
        placeholder="Enter VIN"
        value={vin}
        onChange={(e) => setVin(e.target.value)}
        style={{ padding: 10, marginBottom: 10, width: '100%' }}
      />
      <input
        type="file"
        accept=".pdf"
        onChange={(e) => setFile(e.target.files[0])}
        style={{ marginBottom: 10 }}
      />
      <button onClick={handleSubmit} style={{ padding: 10 }}>Analyze</button>

      {result && (
        <div style={{ marginTop: 20 }}>
          <h2>Result</h2>
          <pre>{JSON.stringify(result, null, 2)}</pre>
        </div>
      )}
    </div>
  );
}